from keras.layers import Conv2D, MaxPooling2D
from keras.layers import Dense, Dropout, Flatten
from keras.models import Sequential


def create_structure(dataset_name, model_name):
    if dataset_name == 'MNIST':
        if model_name == 'model 1':
            return Sequential([
                Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(28, 28, 1)),
                MaxPooling2D(pool_size=(2, 2)),
                Conv2D(16, (5, 5), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Flatten(),
                Dense(120, activation='relu'),
                Dense(84, activation='relu'),
                Dense(10, activation='softmax')])

        if model_name == 'model 2':
            return Sequential([
                Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1)),
                Conv2D(64, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Flatten(),
                Dense(128, activation='relu'),
                Dropout(0.5),
                Dense(10, activation='softmax')])

        print('model structure not found!')
        raise NameError

    if dataset_name == 'CIFAR 10':
        if model_name == 'model 1':
            return Sequential([
                Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(32, 32, 3)),
                MaxPooling2D(pool_size=(2, 2)),
                Conv2D(16, (5, 5), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Flatten(),
                Dense(120, activation='relu'),
                Dense(84, activation='relu'),
                Dense(10, activation='softmax')])
        if model_name == 'model 2':
            return Sequential([
                Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(32, 32, 3)),
                Conv2D(32, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Conv2D(64, (3, 3), activation='relu'),
                Conv2D(64, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Flatten(),
                Dense(512, activation='relu'),
                Dropout(0.5),
                Dense(10, activation='softmax')])

        print('model structure not found!')
        raise NameError
