import os
import keras
from keras import backend as K
from keras.datasets import mnist

from game.structure import create_structure
from game_management.extensive_form_game import ExtensiveFormGame
from operators import model_mut_model_generators
from operators.activation_function_operators import operator_change_activation_function as CAF
from operators.bias_operators import operator_remove_bias as RB
from operators.dropout_operators import operator_change_dropout_rate as CDR

((x_train, y_train), (x_test, y_test)) = mnist.load_data()
(img_rows, img_cols) = (28, 28)
num_classes = 10

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)


def create_game(analysis, dataset_name='MNIST', model_name='model 1', actions=None):
    n_players = 1
    if actions is None:
        actions = ['GF', 'WS', 'NS', 'Train', 'CAF', 'RB', 'CDR', 'Done']

    if not actions:
        print('no actions!')
        raise ModuleNotFoundError

    def isTerminal(board):
        history = board['history']
        return history[-1] == 'Done'

    def identity(board):
        history = board['history']
        actions_can_only_be_done_once = list(filter(lambda comp: comp in ['Train', 'CAF', 'RB', 'CDR'], actions))
        ans = list(filter(lambda action: action not in history, actions_can_only_be_done_once))

        if 'Train' in history:
            actions_can_only_be_done_after_train = list(filter(lambda comp: comp in ['GF', 'WS', 'NS'], actions))
            ans.extend(actions_can_only_be_done_after_train)
            n = max(len(ans), 1)
            for _ in range(n):
                ans.append('Done')

        return ans

    def update(board, player_id, action):
        board['states'].add(player_id, action)

        if action == 'Train':
            model_document_name = '_'.join(sorted(board['states'].show().replace('\'', '').replace(',', '').split()))
            model_location = os.path.join('trained_models', f'{model_document_name}.h5')
            if not os.path.exists(model_location):
                x_train_, y_train_ = board['x_train'], board['y_train']
                x_test_, y_test_ = board['x_test'], board['y_test']
                batch_size, epochs = board['batch_size'], board['epochs']
                loss, optimizer = board['loss'], board['optimizer']

                board['model'].compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])
                board['model'].fit(x_train_, y_train_, batch_size=batch_size, epochs=epochs, verbose=1,
                                   validation_data=(x_test_, y_test_))
                board['model'].save(model_location)
                print(model_document_name, 'is trained and saved at', model_location)
                print()
            else:
                print(model_document_name, 'is loaded from', model_location)
                print()
                board['model'] = keras.models.load_model(model_location)

        elif action in ['GF', 'WS', 'NS']:
            board['model'] = model_mut_model_generators.ModelMutatedModelGenerators(). \
                generate_model_by_model_mutation(board['model'], action, .1)

        else:
            if 'Train' in board['history']:  # if all model is prepared, add this if sentence
                if action == 'CAF':
                    board['model'] = CAF(board['model'])

                elif action == 'RB':
                    board['model'] = RB(board['model'])

                elif action == 'CDR':
                    board['model'] = CDR(board['model'])

                elif action is not 'Done':
                    print('Warning, unknown action', action, '!')
                    raise NotImplementedError

    def init():
        return {'x_train': x_train, 'x_test': x_test,
                'y_train': y_train, 'y_test': y_test,
                'batch_size': 128,
                'epochs': 12,
                'model': create_structure(dataset_name, model_name),
                'loss': keras.losses.categorical_crossentropy,
                'optimizer': keras.optimizers.Adam()}

    return ExtensiveFormGame(n_players, actions, isTerminal, analysis, identity, update,
                             init=init, solo=True)


if __name__ == '__main__':
    from agents.QL_agent import QLAgent


    def analysis_f(x):
        loss, optimizer = x['loss'], x['optimizer']
        x['model'].compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])
        _, score = x['model'].evaluate(x['x_test'], x['y_test'], verbose=0)
        return 1 - score


    agent = QLAgent(0)
    agent.train(create_game(analysis_f),
                arg_change={'learning_rate': .1, 'discount_factor': .9, 'epochs': 250})
