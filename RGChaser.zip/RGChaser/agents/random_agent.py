from random import choice


class RandomAgent:
    def __init__(self, _=None, __=None):
        pass

    def act(self, _, legal_actions, __=None):
        return choice(legal_actions)

    def send(self, _):
        pass
