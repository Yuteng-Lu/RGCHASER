import numpy as np
from random import choice
from agents.random_agent import RandomAgent

import psutil
import os


class QLAgent:
    def __init__(self, player, _=None, q_table=None, name=None, verbose=True, init_arg=0., baseline=0.,
                 lr=.01, df=.9, lr_decay=1.):
        self.player = player
        self.q_table = {None: {None: 0}} if q_table is None else q_table
        self.learning_rate = lr
        self.discount_factor = df
        self.hi, self.lo = .9, .01  # epsilon_hi, lo
        self.start, self.episode, self.epochs = 0, 0, 100
        self.state, self.action = None, None
        self.training = False
        self.name = 'my_dict' if name is None else name
        self.verbose = verbose
        self.init_arg = init_arg
        self.init_mode = False
        self.baseline = baseline
        self.lr_decay = lr_decay

    def create_state(self, state, legal_actions):
        if state not in self.q_table:
            self.q_table[state] = {action: 0. for action in legal_actions}

    def q_update(self, state, action, utility, next_state):
        current_q = self.q_table[state][action]
        # Bellman function update
        new_q = utility + self.discount_factor * max(self.q_table[next_state].values())
        self.q_table[state][action] += \
            self.learning_rate * (new_q - current_q) * self.lr_decay ** (self.start / self.epochs)

    def act(self, state, legal_actions, utility=0.):
        if utility != 0.:
            print('utility:', utility)

        try:
            state = state.show()
        except AttributeError:
            state = str(state)
        self.create_state(state, legal_actions)
        state_action = self.q_table[state]

        if self.training:
            if self.init_mode:
                x = np.random.rand()
                if x >= self.init_arg:
                    self.init_mode = False
                elif self.verbose is not None:
                    print('init mode!', end='\n' if self.verbose else ' ')

            if not self.init_mode and self.state is not None:
                self.q_update(self.state, self.action, utility, state)

            action = None
            if self.init_mode:
                for _ in range(10):
                    action = choice(legal_actions)
                    if action != 'Done':
                        break
            elif np.random.rand() < self.hi * (self.lo / self.hi) ** (self.episode / self.epochs):
                # random
                if self.verbose is not None:
                    print('random!', end='\n' if self.verbose else ' ')
                action = choice(legal_actions)
            else:
                # greedy
                action = self.arg_max(state_action)

            self.state, self.action = state, action

        else:  # not training
            action = self.arg_max(state_action)
            print(state, action)

        if self.verbose:
            print(state, state_action)
            print(action, state_action[action])
            print()
        elif self.verbose is not None:
            print(action, state_action[action])

        return action

    def send(self, utility):
        if self.training and self.state is not None:
            self.q_update(self.state, self.action, utility - self.baseline, None)
            self.state = None

        if self.verbose:
            print('player:', self.player)

        if utility != 0:
            print('utility:', utility)

        if self.verbose:
            print()

    def train(self, env, players=None, arg_change=None):
        self.training = True

        if arg_change is not None:
            if 'discount_factor' in arg_change:
                self.discount_factor = arg_change['discount_factor']
            if 'hi' in arg_change:
                self.hi = arg_change['hi']
            if 'lo' in arg_change:
                self.lo = arg_change['lo']
            if 'epochs' in arg_change:
                self.epochs = arg_change['epochs']
            if 'name' in arg_change:
                self.name = arg_change['name']
            if 'lr' in arg_change:
                self.learning_rate = arg_change['lr']

        if players is None:
            players = []
            for i in range(env.n_players):
                players.append(self if i == self.player else RandomAgent())

        else:
            players[self.player] = self

        for self.episode in range(self.start, self.epochs):
            print('-------------------------------------------------------')
            print('episode', self.episode + 1, self.name)
            print('Memory：%.2f MB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024))

            if self.training:
                self.init_mode = True
            env.play(players)
            if (self.episode + 1) % 50 == 0:
                np.save(f'{self.name}.npy', self.q_table)

        self.training = False
        self.start = 0

        np.save(f'{self.name}.npy', self.q_table)

        # self.show()

        # for i in range(100):
        #     print('-------------------------------------------------------')
        #     print('Test', i + 1)
        #     env.play(players)

    def show(self):
        for state in self.q_table:
            print(state, self.q_table[state])
        print()

    @staticmethod
    def arg_max(state_action):
        max_index_list = []
        max_value = None
        for index in state_action:
            value = state_action[index]
            if max_value is None or value > max_value:
                max_index_list.clear()
                max_value = value
                max_index_list.append(index)
            elif value == max_value:
                max_index_list.append(index)
        if 'Done' in max_index_list:
            return 'Done'
        return choice(max_index_list)


if __name__ == '__main__':
    from games.kuhn_poker import create_game

    agent = QLAgent(0)
    agent_ = QLAgent(1)
    my_game = create_game()
    agent.train(my_game)
    agent_.train(my_game, [agent, None])
