class HumanAgent:
    def __init__(self, player, _=None):
        self.player = player

    def act(self, state, legal_actions, utility=0.):
        print('player:', self.player)
        print('state:', state.show())
        print('action space:', legal_actions)
        if info is not None:
            print('info:', info)
        print('utility:', utility)

        while True:
            action = input()
            if action in legal_actions:
                print()
                return action
            if action.upper() in legal_actions:
                print()
                return action.upper()
            print('action not legal, please retry')

    def send(self, utility):
        print('player:', self.player)
        print('utility:', utility)
        print()
