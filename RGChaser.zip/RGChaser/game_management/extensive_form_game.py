from agents.human_agent import HumanAgent
from agents.random_agent import RandomAgent
from game_management.tools import State


class ExtensiveFormGame:
    def __init__(self, n_players: int, actions, isTerminal, utilities, identity, update,
                 chance=None, init=None, solo=False, non_terminal_utilities=None):
        self.n_players = n_players  # number of players
        self.actions = actions  # a finite set of actions a player can take
        self.isTerminal = isTerminal  # a subset of terminal histories (actually an identity function for that)
        self.utilities = utilities  # assigns utility for each player at terminal states
        self.identity = identity  # identifies which player to act and legal actions at each history
        self.update = update  # update game info for each player at each history

        self.chance = chance  # a special player for the game called the chance node
        self.init = init  # initialisation of game info
        self.solo = solo  # True if n_players == 1 and no chance node
        self.non_terminal_utilities = lambda _, __: 0 if non_terminal_utilities is None else non_terminal_utilities
        # assigns utility for each player at non terminal states

        self.board = {}  # game board for saving info
        self.players = []  # players for the game
        self.min_utility = 0.  # used to punish illegal actions
        self.utility = 0.

    def change_players(self, players):
        if isinstance(players, str):
            self.players = []
            players = players.split('v')

            # prepare players
            for player_id in range(self.n_players):
                agent = players[player_id]
                if agent == 'p':
                    self.players.append(HumanAgent(player_id, self.actions))
                else:  # agent == 'r'
                    self.players.append(RandomAgent(player_id, self.actions))

        else:
            self.players = players.copy()

    def start(self, players):  # start game with the players
        self.board = {} if self.init is None else self.init()  # game info
        self.board['history'] = []
        self.utility = 0.

        self.change_players(players)

        if 'states' not in self.board:
            if self.solo:
                self.board['states'] = State(solo=True)
            else:
                self.board['states'] = [State() for _ in self.players]

    def step(self, action=None):  # ask for next action
        if self.solo:
            legal_actions = self.identity(self.board)
            if action is not None and action not in legal_actions:
                return False
            utility = self.non_terminal_utilities(self.board, self.players[0])
            self.utility += utility

            while action not in legal_actions:
                action = self.players[0].act(self.board['states'].copy(), legal_actions, utility)

            self.update(self.board, 0, action)
            self.board['history'].append(action)

        else:
            player_id, legal_actions = self.identity(self.board)
            if player_id is None:  # chance node
                if action is None:
                    action = self.chance(self.board)
            else:  # if player is controllable player
                utility = self.non_terminal_utilities(self.board, self.players[player_id])
                if utility < self.min_utility:
                    self.min_utility = utility
                while action not in legal_actions:
                    action = self.players[player_id].act(self.board['states'][player_id].copy(), legal_actions, utility)
                    utility = self.min_utility - 1

            self.update(self.board, player_id, action)
            self.board['history'].append((player_id, action))

        return True

    def end(self):  # end game
        if self.solo:
            utility = self.utilities(self.board)
            self.utility += utility
            self.players[0].send(utility)
        else:
            utilities = self.utilities(self.board)
            for player_id in range(self.n_players):
                utility = utilities[player_id]
                if utility < self.min_utility:
                    self.min_utility = utility
                self.players[player_id].send(utilities[player_id])

    def play(self, players):
        # prepare game
        self.start(players)

        # start game
        while not self.isTerminal(self.board):
            self.step()

        # end game
        self.end()

        return self.utility
