from random import shuffle
from enum import Enum


class Deck:
    def __init__(self, cards):
        shuffle(cards)
        self.cards = cards

    def isEmpty(self):
        return self.cards == []

    def draw(self):
        card = self.cards[-1]
        del self.cards[-1]
        return card


class State:
    def __init__(self, state=None, solo=False):
        self.state = [] if state is None else state
        self.solo = solo

    def isEmpty(self):
        return self.state == []

    def add(self, player_id, action, hidden=False, index=-1):
        if index == -1:
            self.state.append(action if self.solo else (player_id, '?' if hidden else action))
        else:
            new_state = self.state[: index]
            new_state.append(action if self.solo else (player_id, '?' if hidden else action))
            new_state.extend(self.state[index:])
            self.state = new_state

    def show(self):
        if not str(self.state)[1: -1]:
            return '0'
        return str(self.state)[1: -1]

    def copy(self):
        return State(self.state.copy())

    def change(self, index, value):
        self.state[index] = value

    def backspace(self, min_len=0):
        if len(self.state) > min_len:
            del self.state[-1]
            return True
        return False


class GameState(Enum):
    g_over = -1
    g_continue = 1
    g_resign = 0
