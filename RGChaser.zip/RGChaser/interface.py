from PIL import Image, ImageTk
import tkinter as tk
from main import play


def resize(w, h, w_box, h_box, image):
    f1 = w_box / w
    f2 = h_box / h
    factor = max([f1, f2])
    width = int(w * factor)
    height = int(h * factor)
    return image.resize((width, height), Image.Resampling.LANCZOS)


def all_zero(my_list):
    for val in my_list:
        if isinstance(val, list):
            if not all_zero(val):
                return False
        else:
            # print(val)
            if val != 0:
                return False
    return True


def create_window():
    window = tk.Tk()
    route = f'wallpaper\\blue.jpg'
    image = Image.open(route)
    w, h = 1280, 800
    w_, h_ = image.size
    y = 0
    image_resized = resize(w_, h_, w, h, image)
    tk_image = ImageTk.PhotoImage(image_resized)
    background_label = tk.Label(window, image=tk_image)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)

    for i in range(2):
        window.rowconfigure(i, weight=1, minsize=300)
    for j in range(3):
        window.columnconfigure(j, weight=1, minsize=240)

    frame = []
    title = [['-----------Dataset-----------', '---------Parameters---------', '--------More Options--------'],
             ['-----Mutation Operators-----', '------------Actions-------------', '----------Start here----------']]
    for i in range(len(title)):
        frame.append([])
        for j in range(len(title[i])):
            frame[-1].append(tk.Frame(master=window, borderwidth=1))
            frame[i][j].grid(row=i, column=j, padx=5, pady=5)
            label = tk.Label(master=frame[i][j], text=title[i][j])
            label.pack(padx=5, pady=5)

    # frame (0, 0)
    my_frame = frame[0][0]
    text1 = ['MNIST', 'CIFAR-10']

    def sel1():
        selection = f'You selected {text1[RadioVar.get()]}'
        label1.config(text=selection)

    RadioVar = tk.IntVar()
    R1 = []

    for k in range(len(text1)):
        R = tk.Radiobutton(my_frame, text=text1[k], variable=RadioVar, value=k, command=sel1)
        R1.append(R)
        if k % 2 == 0:
            R.pack(anchor='w')
            R.update()
            y = R.winfo_y() - 1
        else:
            R.place(x=90, y=y)

    label1 = tk.Label(my_frame)
    label1.pack()
    sel1()

    label = tk.Label(master=my_frame, text='------------Model--------------')
    label.pack()

    text2 = ['model 1', 'model 2']
    RadioVar2 = tk.IntVar()
    R2 = []

    def sel2():
        selection = f'You selected {text2[RadioVar2.get()]}'
        label2.config(text=selection)

    for k in range(len(text2)):
        R = tk.Radiobutton(my_frame, text=text2[k], variable=RadioVar2, value=k, command=sel2)
        R2.append(R)
        if k % 2 == 0:
            R.pack(anchor='w')
            R.update()
            y = R.winfo_y() - 1
        else:
            R.place(x=90, y=y)

    label2 = tk.Label(my_frame)
    label2.pack()
    sel2()

    def see():
        window1 = tk.Toplevel()
        text_ = [[
            '''model 1:
Sequential([
Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(28, 28, 1)),
MaxPooling2D(pool_size=(2, 2)),
Conv2D(16, (5, 5), activation='relu'),
MaxPooling2D(pool_size=(2, 2)),
Flatten(),
Dense(120, activation='relu'),
Dense(84, activation='relu'),
Dense(10, activation='softmax')
])''',

            '''model 2:
Sequential([
Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1)),
Conv2D(64, (3, 3), activation='relu'),
MaxPooling2D(pool_size=(2, 2)),
Dropout(0.25),
Flatten(),
Dense(128, activation='relu'),
Dropout(0.5),
Dense(10, activation='softmax')
])'''],
            ['''model 1:
Sequential([
Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(32, 32, 3)),
MaxPooling2D(pool_size=(2, 2)),
Conv2D(16, (5, 5), activation='relu'),
MaxPooling2D(pool_size=(2, 2)),
Flatten(),
Dense(120, activation='relu'),
Dense(84, activation='relu'),
Dense(10, activation='softmax')
])''',
             '''model 2:
Sequential([
Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(32, 32, 3)),
Conv2D(32, (3, 3), activation='relu'),
MaxPooling2D(pool_size=(2, 2)),
Dropout(0.25),
Conv2D(64, (3, 3), activation='relu'),
Conv2D(64, (3, 3), activation='relu'),
MaxPooling2D(pool_size=(2, 2)),
Dropout(0.25),
Flatten(),
Dense(512, activation='relu'),
Dropout(0.5),
Dense(10, activation='softmax'),
])''']

        ]

        detail = tk.Label(window1, justify='left', text='\n'.join(text_[RadioVar.get()]))
        detail.pack(anchor='w')

    C = tk.Button(my_frame, text='see details', width=20, bg='cyan', command=see)
    C.pack(padx=5, pady=5)

    # frame (0, 1)
    my_frame = frame[0][1]

    label = tk.Label(my_frame, text='max_steps: Z+')
    entry1 = tk.Entry(my_frame, width=10)
    label.pack(anchor='w')
    entry1.place(x=95, y=33)
    entry1.insert(1, '10')

    label = tk.Label(my_frame, text='init_arg: [0, 1)')
    entry2 = tk.Entry(my_frame, width=10)
    label.pack(anchor='w')
    entry2.place(x=95, y=56)
    entry2.insert(1, '1/3')

    label = tk.Label(my_frame, text='epochs: Z+')
    entry3 = tk.Entry(my_frame, width=10)
    label.pack(anchor='w')
    entry3.place(x=95, y=79)
    entry3.insert(1, '60000')

    label6 = tk.Label(my_frame)
    label6.pack()

    # frame (1, 0)
    my_frame = frame[1][0]
    valid_modes3 = ['GF', 'WS', 'NS', 'CAF', 'RB', 'CDR']
    CheckVar3 = [tk.IntVar() for _ in range(len(valid_modes3))]
    Checkbuttons3 = []

    for k in range(len(valid_modes3)):
        C = tk.Checkbutton(my_frame, text=valid_modes3[k], variable=CheckVar3[k], onvalue=1, offvalue=0)
        C.select()
        if k % 2 == 0:
            C.pack(anchor='w')
            C.update()
            y = C.winfo_y() - 1
        else:
            C.place(x=90, y=y)
        Checkbuttons3.append(C)

    def choose_all3():
        for c in Checkbuttons3:
            c.select()

    def remove_all3():
        for c in Checkbuttons3:
            c.deselect()

    C = tk.Button(my_frame, text='choose all', command=choose_all3, bg='yellow')
    C.pack(anchor='w', padx=10, pady=5)
    C.update()
    y = C.winfo_y() - 1

    C = tk.Button(my_frame, text='remove all', command=remove_all3, bg='red', fg='yellow')
    C.place(x=100, y=y)

    def set3():
        window3 = tk.Toplevel()

        for i_ in range(len(valid_modes3)):
            window.rowconfigure(i_, weight=1)
        for j_ in range(2):
            window.columnconfigure(j_, weight=1)
        for i_ in range(len(valid_modes3)):
            F = tk.Frame(master=window3, borderwidth=1)
            F.grid(row=i_, column=0, padx=5, pady=5)
            L = tk.Label(F, text=valid_modes3[i_])
            L.pack(padx=5, pady=5)
            F = tk.Frame(master=window3, borderwidth=1)
            F.grid(row=i_, column=1, padx=5, pady=5)
            if valid_modes3[i_] in ['GF', 'WS', 'NS']:
                E = tk.Entry(F, width=15)
                E.pack(padx=5, pady=5)
                E.insert(1, '0.1')
            elif valid_modes3[i_] in ['CAF', 'RB', 'CDR']:
                L = tk.Label(F, text='change parameters in utils\\properties')
                L.pack(padx=5, pady=5)
        window3.mainloop()

    C = tk.Button(my_frame, text='set details', command=set3, width=20, bg='cyan')
    C.pack(padx=5, pady=5)

    label3 = tk.Label(my_frame)
    label3.pack()

    # frame (1, 1)
    my_frame = frame[1][1]

    valid_modes4 = ['Contrast', 'Brightness', 'Noise', 'Translation', 'Scaling', 'Shearing', 'Revolution']
    CheckVar4 = [tk.IntVar() for _ in range(len(valid_modes4))]
    Checkbuttons4 = []

    detail_modes = [['Contrast+', 'Contrast-'],
                    ['Brightness+', 'Brightness-'],
                    ['Blur', 'Noise_SP', 'Noise_Gauss'],
                    ['Translation_up', 'Translation_down', 'Translation_left', 'Translation_right'],
                    ['Scaling_vertical+', 'Scaling_vertical-', 'Scaling_horizontal+', 'Scaling_horizontal-'],
                    ['Shear_vertical+', 'Shear_vertical-', 'Shear_horizontal+', 'Shear_horizontal-'],
                    ['Revolution_0', 'Revolution_1', 'Revolution_2', 'Revolution_3']]
    CheckVar5 = [[tk.IntVar() for _ in detail_modes[i]] for i in range(len(detail_modes))]
    Checkbuttons5 = []
    for k in range(len(valid_modes4)):
        C = tk.Checkbutton(my_frame, text=valid_modes4[k], variable=CheckVar4[k],
                           onvalue=1, offvalue=0)
        C.select()
        if k % 2 == 0:
            C.pack(anchor='w')
            C.update()
            y = C.winfo_y() - 1
        else:
            C.place(x=90, y=y)

        Checkbuttons4.append(C)

    def choose_all4():
        for c in Checkbuttons4:
            c.select()
        refresh()

    def remove_all4():
        for c in Checkbuttons4:
            c.deselect()
        refresh()

    C = tk.Button(my_frame, text='choose all', command=choose_all4, bg='yellow')
    C.pack(anchor='w', padx=7, pady=5)
    # C.update()
    # print(C.winfo_y())

    C = tk.Button(my_frame, text='remove all', command=remove_all4, bg='red', fg='yellow')
    C.place(x=93, y=146)

    def set4():
        nonlocal Checkbuttons5
        window4 = tk.Toplevel()

        def sel5(line):
            def sel():
                if all_zero(list(map(lambda z: z.get(), CheckVar5[line]))):
                    Checkbuttons4[line].deselect()
                else:
                    Checkbuttons4[line].select()

            return sel

        for i_ in range(len(detail_modes)):
            window.rowconfigure(i_, weight=1)
        for j_ in range(4):
            window.columnconfigure(j_, weight=1)
        if Checkbuttons5:
            for i_ in range(len(detail_modes)):
                for j_ in range(len(detail_modes[i_])):
                    if Checkbuttons5[i_]:
                        F = tk.Frame(master=window4, borderwidth=1)
                        F.grid(row=i_, column=j_, padx=5, pady=5)
                        C_ = tk.Checkbutton(F, text=detail_modes[i_][j_], variable=CheckVar5[i_][j_],
                                            onvalue=1, offvalue=0, command=sel5(i_))
                        C_.pack(padx=5, pady=5)
        else:
            for i_ in range(len(detail_modes)):
                Checkbuttons5.append([])
                for j_ in range(len(detail_modes[i_])):
                    F = tk.Frame(master=window4, borderwidth=1)
                    F.grid(row=i_, column=j_, padx=5, pady=5)
                    C_ = tk.Checkbutton(F, text=detail_modes[i_][j_], variable=CheckVar5[i_][j_],
                                        onvalue=1, offvalue=0, command=sel5(i_))
                    if CheckVar4[i_].get() == 1:
                        C_.select()
                    else:
                        C_.deselect()
                    C_.pack(padx=5, pady=5)

                    Checkbuttons5[-1].append(C_)
        window4.mainloop()

    C = tk.Button(my_frame, text='set details', width=20, bg='cyan', command=set4)
    C.pack(padx=5, pady=5)

    def refresh():
        nonlocal CheckVar5, Checkbuttons5
        CheckVar5 = [[tk.IntVar() for _ in detail_modes[i_]] for i_ in range(len(detail_modes))]
        Checkbuttons5 = []

    C = tk.Button(my_frame, text='refresh details', command=refresh, width=20, bg='red', fg='yellow')
    C.pack(padx=5, pady=5)

    # frame (0, 2)
    my_frame = frame[0][2]

    text5 = ['dataset', 'model', 'operators', 'actions', 'property_m', 'property_t']
    RadioVar5 = tk.IntVar()
    R5 = []

    for k in range(len(text5)):
        R = tk.Radiobutton(my_frame, text=text5[k], variable=RadioVar5, value=k, command=sel1)
        R5.append(R)
        if k % 2 == 0:
            R.pack(anchor='w')
            R.update()
            y = R.winfo_y() - 1
        else:
            R5[-1].update()
            R.place(x=90, y=y)

    R = tk.Radiobutton(my_frame, variable=RadioVar5, value=-1)
    R.select()

    def play5():
        if RadioVar5.get() >= 4:
            return

        window5 = tk.Toplevel()

        def play5_():
            print(T.get())
            window5.destroy()

        T = tk.Entry(window5)
        T.pack()
        B = tk.Button(window5, text='submit path', command=play5_, width=20, height=1, bg='cyan')
        B.pack(padx=5, pady=5)
        window5.mainloop()

    C = tk.Button(my_frame, text='submit', command=play5, width=10, height=1, bg='cyan')
    C.pack(padx=5, pady=5)

    # frame (1, 2)
    my_frame = frame[1][2]

    def play6():
        C3 = list(map(lambda x: x.get(), CheckVar3))
        C4 = list(map(lambda x: x.get(), CheckVar4))
        C5 = list(map(lambda x: list(map(lambda z: z.get(), x)), CheckVar5))

        warning = ''
        a1, a2, a3 = int(entry1.get()), float(eval(entry2.get())), int(entry3.get())
        if a1 <= 0:
            warning = warning + 'max_steps, '
        if a2 < 0 or a2 >= 1:
            warning = warning + 'init_arg, '
        if a3 <= 0:
            warning = warning + 'epochs, '

        if warning:
            label6.config(text=f'{warning[: -2]} ValueError')
        else:
            label6.config(text='')

        if all_zero(C3) and all_zero(C4) and all_zero(C5):
            label3.config(text='no operators and no actions')
            return
        else:
            label3.config(text='')

        if warning:
            return

        actions = []
        for t in range(len(C4)):
            if C4[t] == 1:
                if all_zero(C5[t]):
                    for u in range(len(C5[t])):
                        C5[t][u] = 1
                actions.extend(list(map(lambda s: detail_modes[t][s],
                                        list(filter(lambda s: C5[t][s] > 0, range(len(detail_modes[t])))))))

        play(text1[RadioVar.get()], text2[RadioVar2.get()], a1, a2, a3,
             list(map(lambda s: valid_modes3[s], list(filter(lambda s: C3[s] > 0, range(len(valid_modes3)))))),
             actions)

    C = tk.Button(my_frame, text='play', command=play6, width=10, height=2, bg='cyan')
    C.pack(padx=5, pady=5)

    window.mainloop()


if __name__ == '__main__':
    create_window()
