from keras import Sequential
from keras.datasets import mnist, cifar10
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.utils import to_categorical


def create_dataset(dataset_name):
    if dataset_name == 'MNIST':
        (x_train, y_train), (x_test, y_test) = mnist.load_data()
        x_train = x_train.reshape(60000, 28, 28, 1)
        x_test = x_test.reshape(10000, 28, 28, 1)
        x_train, x_test = x_train / 255., x_test / 255.
        y_train = to_categorical(y_train, 10)
        y_test = to_categorical(y_test, 10)
        return (x_train, y_train), (x_test, y_test)

    if dataset_name == 'CIFAR-10':
        (x_train, y_train), (x_test, y_test) = cifar10.load_data()
        x_train = x_train.reshape(50000, 32, 32, 3)
        x_test = x_test.reshape(10000, 32, 32, 3)
        x_train, x_test = x_train / 255., x_test / 255.
        y_train = to_categorical(y_train, 10)
        y_test = to_categorical(y_test, 10)
        return (x_train, y_train), (x_test, y_test)


def create_model(dataset_name, model_name):
    if dataset_name == 'MNIST':
        if model_name == 'model 1':
            return Sequential([
                Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(28, 28, 1)),
                MaxPooling2D(pool_size=(2, 2)),
                Conv2D(16, (5, 5), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Flatten(),
                Dense(120, activation='relu'),
                Dense(84, activation='relu'),
                Dense(10, activation='softmax')
            ])
        if model_name == 'model 2':
            return Sequential([
                Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1)),
                Conv2D(64, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Flatten(),
                Dense(128, activation='relu'),
                Dropout(0.5),
                Dense(10, activation='softmax')
            ])

    if dataset_name == 'CIFAR-10':
        if model_name == 'model 1':
            return Sequential([
                Conv2D(6, kernel_size=(5, 5), activation='relu', input_shape=(32, 32, 3)),
                MaxPooling2D(pool_size=(2, 2)),
                Conv2D(16, (5, 5), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Flatten(),
                Dense(120, activation='relu'),
                Dense(84, activation='relu'),
                Dense(10, activation='softmax')
            ])
        if model_name == 'model 2':
            return Sequential([
                Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(32, 32, 3)),
                Conv2D(32, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Conv2D(64, (3, 3), activation='relu'),
                Conv2D(64, (3, 3), activation='relu'),
                MaxPooling2D(pool_size=(2, 2)),
                Dropout(0.25),
                Flatten(),
                Dense(512, activation='relu'),
                Dropout(0.5),
                Dense(10, activation='softmax'),
            ])


def create_agent(entry2, entry3):
    pass


def create_env(dataset_name, model_name, entry1, mutations, actions):
    pass


def play(dataset_name, model_name, entry1, entry2, entry3, mutations, actions):
    print(dataset_name, model_name, entry1, entry2, entry3, mutations, actions, sep='\n')
    print()
