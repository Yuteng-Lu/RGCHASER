# coding=utf-8
import cv2
import numpy as np
import random

import numbers_mnist

valid_modes = [
    'Contrast+', 'Contrast-', 'Brightness+', 'Brightness-', 'Blur', 'Noise_SP', 'Noise_Gauss',
    'Translation_up', 'Translation_down', 'Translation_left', 'Translation_right',
    'Scaling_vertical+', 'Scaling_vertical-', 'Scaling_horizontal+', 'Scaling_horizontal-',
    'Shear_vertical+', 'Shear_vertical-', 'Shear_horizontal+', 'Shear_horizontal-',
    'Revolution_0', 'Revolution_1', 'Revolution_2', 'Revolution_3',
    'Done']
action_space = [
    'Contrast+', 'Contrast-', 'Brightness+', 'Brightness-', 'Blur', 'Noise_SP', 'Noise_Gauss',
    'Translation_up', 'Translation_down', 'Translation_left', 'Translation_right',
    'Scaling_vertical+', 'Scaling_vertical-', 'Scaling_horizontal+', 'Scaling_horizontal-',
    'Shear_vertical+', 'Shear_vertical-', 'Shear_horizontal+', 'Shear_horizontal-',
    'Revolution_0', 'Revolution_1', 'Revolution_2', 'Revolution_3',
    'Done', 'Done', 'Done', 'Done', 'Done', 'Done', 'Done', 'Done', 'Done', 'Done']


# valid_modes = ['Revolution_0', 'Revolution_1', 'Revolution_2', 'Revolution_3',
#                'Done']
# action_space = ['Revolution_0', 'Revolution_1', 'Revolution_2', 'Revolution_3',
#                 'Done', 'Done', 'Done', 'Done']


def operate(image, mode):
    assert mode in valid_modes, 'Input mode ' + mode + ' is not implemented'

    if mode == 'Contrast+':
        return ImageOperations.contrast_hi(image)

    elif mode == 'Contrast-':
        return ImageOperations.contrast_lo(image)

    elif mode == 'Brightness+':
        return ImageOperations.brightness_hi(image)

    elif mode == 'Brightness-':
        return ImageOperations.brightness_lo(image)

    elif mode == 'Blur':
        return ImageOperations.blur(image)

    elif mode == 'Noise_SP':
        return ImageOperations.noise_SP(image)

    elif mode == 'Noise_Gauss':
        return ImageOperations.noise_Gauss(image)

    elif mode == 'Translation_up':
        return ImageOperations.translation_up(image)

    elif mode == 'Translation_down':
        return ImageOperations.translation_down(image)

    elif mode == 'Translation_left':
        return ImageOperations.translation_left(image)

    elif mode == 'Translation_right':
        return ImageOperations.translation_right(image)

    elif mode == 'Scaling_vertical+':
        return ImageOperations.scaling_vertical_hi(image)

    elif mode == 'Scaling_vertical-':
        return ImageOperations.scaling_vertical_lo(image)

    elif mode == 'Scaling_horizontal+':
        return ImageOperations.scaling_horizontal_hi(image)

    elif mode == 'Scaling_horizontal-':
        return ImageOperations.scaling_horizontal_lo(image)

    elif mode == 'Shear_vertical+':
        return ImageOperations.shear_vertical_0(image)

    elif mode == 'Shear_vertical-':
        return ImageOperations.shear_vertical_1(image)

    elif mode == 'Shear_horizontal+':
        return ImageOperations.shear_horizontal_0(image)

    elif mode == 'Shear_horizontal-':
        return ImageOperations.shear_horizontal_1(image)

    elif mode == 'Revolution_0':
        return ImageOperations.revolution_0(image)

    elif mode == 'Revolution_1':
        return ImageOperations.revolution_1(image)

    elif mode == 'Revolution_2':
        return ImageOperations.revolution_2(image)

    elif mode == 'Revolution_3':
        return ImageOperations.revolution_3(image)

    else:  # mode == 'Done'
        return image


def show(image):
    img_300x300 = cv2.resize(image, (300, 300))
    cv2.imshow('image', img_300x300)
    cv2.waitKey(0)


class ImageOperations:
    def __init__(self):
        pass

    @staticmethod
    def contrast_hi(image):
        arg = 3 / 2
        phi = arg ** np.random.rand()
        output = np.zeros(image.shape, np.float32)
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                output[i][j] = (image[i][j] - .5) * phi + .5
        return output

    @staticmethod
    def contrast_lo(image):
        arg = 2 / 3
        phi = arg ** np.random.rand()
        output = np.zeros(image.shape, np.float32)
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                output[i][j] = (image[i][j] - .5) * phi + .5
        return output

    @staticmethod
    def brightness_hi(image):
        arg = .25
        phi = arg ** np.random.rand()
        output = np.zeros(image.shape, np.float32)
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                output[i][j] = image[i][j] + phi
        return output

    @staticmethod
    def brightness_lo(image):
        arg = .25
        phi = arg ** np.random.rand()
        output = np.zeros(image.shape, np.float32)
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                output[i][j] = image[i][j] - phi
        return output

    @staticmethod
    def blur(image):
        arg = 3
        size = 3 + 2 * np.random.randint(0, arg)
        return cv2.GaussianBlur(image, ksize=(size, size), sigmaX=0, sigmaY=0)

    @staticmethod
    def noise_SP(image):
        prob = .01
        output = np.zeros(image.shape, np.float32)
        threshold = 1 - prob
        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                rdn = np.random.rand()
                if rdn < prob:
                    output[i][j] = 0
                elif rdn > threshold:
                    output[i][j] = 1
                else:
                    output[i][j] = image[i][j]
        return output

    @staticmethod
    def noise_Gauss(image):
        var = .01
        noise = np.random.normal(0, var ** .5, image.shape)
        output = image + noise
        output = np.clip(output, 0., 1.)
        return output

    @staticmethod
    def translation_up(image):
        arg = 10
        x = arg * np.random.rand()
        matrix = np.array([
            [1, 0, 0],
            [0, 1, -x]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def translation_down(image):
        arg = 10
        x = arg * np.random.rand()
        matrix = np.array([
            [1, 0, 0],
            [0, 1, x]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def translation_left(image):
        arg = 10
        x = arg * np.random.rand()
        matrix = np.array([
            [1, 0, -x],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def translation_right(image):
        arg = 10
        x = arg * np.random.rand()
        matrix = np.array([
            [1, 0, x],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def scaling_vertical_hi(image):
        arg = 1.5
        x = arg ** np.random.rand()
        matrix = np.array([
            [x, 0, (1 - x) / 2 * image.shape[0]],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def scaling_vertical_lo(image):
        arg = 2 / 3
        x = arg ** np.random.rand()
        matrix = np.array([
            [x, 0, (1 - x) / 2 * image.shape[0]],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def scaling_horizontal_hi(image):
        arg = 1.5
        x = arg ** np.random.rand()
        matrix = np.array([
            [1, 0, 0],
            [0, x, (1 - x) / 2 * image.shape[1]]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def scaling_horizontal_lo(image):
        arg = 2 / 3
        x = arg ** np.random.rand()
        matrix = np.array([
            [1, 0, 0],
            [0, x, (1 - x) / 2 * image.shape[1]]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def shear_vertical_0(image):
        arg = .5
        phi = arg * np.random.rand() + .1
        matrix = np.array([
            [1, 0, 0],
            [phi, 1, -phi / 2 * image.shape[0]]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def shear_vertical_1(image):
        arg = -.5
        phi = arg * np.random.rand() - .1
        matrix = np.array([
            [1, 0, 0],
            [phi, 1, -phi / 2 * image.shape[0]]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def shear_horizontal_0(image):
        arg = .5
        phi = arg * np.random.rand() + .1
        matrix = np.array([
            [1, phi, -phi / 2 * image.shape[1]],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def shear_horizontal_1(image):
        arg = -.5
        phi = arg * np.random.rand() - .1
        matrix = np.array([
            [1, phi, -phi / 2 * image.shape[1]],
            [0, 1, 0]
        ], dtype=np.float32)
        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def revolution(image, theta):
        matrix = np.array([
            [np.cos(theta), -np.sin(theta),
             (1 - np.cos(theta)) / 2 * image.shape[0] + np.sin(theta) / 2 * image.shape[1]],
            [np.sin(theta), np.cos(theta),
             -np.sin(theta) / 2 * image.shape[1] + (1 - np.cos(theta)) / 2 * image.shape[1]]
        ], dtype=np.float32)

        return cv2.warpAffine(image, matrix, image.shape[:2])

    @staticmethod
    def revolution_0(image):
        arg = np.pi / 4
        theta = arg * (2 * np.random.rand() - 1)
        return ImageOperations.revolution(image, theta)

    @staticmethod
    def revolution_1(image):
        arg = np.pi / 4
        theta = arg * (2 * np.random.rand() + 1)
        return ImageOperations.revolution(image, theta)

    @staticmethod
    def revolution_2(image):
        arg = np.pi / 4
        theta = arg * (2 * np.random.rand() + 3)
        return ImageOperations.revolution(image, theta)

    @staticmethod
    def revolution_3(image):
        arg = np.pi / 4
        theta = arg * (2 * np.random.rand() + 5)
        return ImageOperations.revolution(image, theta)


if __name__ == '__main__':
    for _ in range(100):
        img = random.choice(numbers_mnist.test_images_) / 255
        show(img)
        for valid_mode in valid_modes:
            print(valid_mode)
            new_img = operate(img, valid_mode)
            show(new_img)
